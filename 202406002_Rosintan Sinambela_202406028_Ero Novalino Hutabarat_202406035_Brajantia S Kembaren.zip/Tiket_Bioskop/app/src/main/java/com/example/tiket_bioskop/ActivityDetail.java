package com.example.tiket_bioskop;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

public class ActivityDetail extends AppCompatActivity {
    ImageView civpoto;
    TextView tvnama, tvmovie, tvdes;
    Button btnbook;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        getSupportActionBar().setTitle("Tiket Bioskop");

        civpoto = (ImageView) findViewById(R.id.civ_potodtl);
        tvnama = (TextView) findViewById(R.id.tv_namadtl);
        tvmovie = (TextView) findViewById(R.id.tv_moviedtl);
        tvdes = (TextView) findViewById(R.id.tv_desdtl);
        btnbook = (Button) findViewById(R.id.btn_book);
        btnbook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ActivityDetail.this, BookingActivity.class);
                startActivity(intent);
            }
        });

        String nama = getIntent().getStringExtra("EXTRA_NAMA");
        String movie = getIntent().getStringExtra("EXTRA_MOVIE");
        String des = getIntent().getStringExtra("EXTRA_DES");
        int poto = getIntent().getIntExtra("EXTRA_POTO", R.drawable.ic_launcher_background);

        tvnama.setText(nama);
        tvmovie.setText(movie);
        tvdes.setText(des);
        Glide.with(this).load(poto).into(civpoto);

    }
}
