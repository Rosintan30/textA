package com.example.tiket_bioskop;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import com.google.firebase.auth.FirebaseAuth;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    RecyclerView rvfilm;
    ArrayList<Movie> datalist;
    FirebaseAuth mAuth;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.menulog){
            mAuth.signOut();
            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
            startActivity(intent);
        }
        return true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().setTitle("Tiket Bioskop");
        mAuth = FirebaseAuth.getInstance();

        addData();
        rvfilm = (RecyclerView) findViewById(R.id.rv_film);
        MovieAdapterList movieAdapterList = new MovieAdapterList(datalist);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
        rvfilm.setLayoutManager(layoutManager);
        rvfilm.setAdapter(movieAdapterList);

        movieAdapterList.setOnItemClickCallback(new MovieAdapterList.OnItemClickCallback() {
            @Override
            public void onClicked(Movie data) {
                Intent intent = new Intent(MainActivity.this, ActivityDetail.class);
                intent.putExtra("EXTRA_NAMA", data.getNama());
                intent.putExtra("EXTRA_MOVIE", data.getMovie());
                intent.putExtra("EXTRA_DES", data.getDes());
                intent.putExtra("EXTRA_POTO", data.getPoto());
                startActivity(intent);
            }
        });
    }

    void addData(){
        datalist = new ArrayList<Movie>();
        datalist.add(new Movie("Free Guy","On Cinema","A bank teller discovers that he's actually an NPC inside a brutal, open world video game.", R.drawable.freeguy));
        datalist.add(new Movie("The Suicide Squad","On Cinema","Supervillains Harley Quinn, Bloodsport, Peacemaker and a collection of nutty cons at Belle Reve prison join the super-secret, super-shady Task Force X as they are dropped off at the remote, enemy-infused island of Corto Maltese.", R.drawable.suicide));
        datalist.add(new Movie("Shang-Chi","On Cinema","Shang-Chi, the master of weaponry-based Kung Fu, is forced to confront his past after being drawn into the Ten Rings organization.", R.drawable.shang));
        datalist.add(new Movie("Jungle Cruise","On Cinema","Based on Disneyland's theme park ride where a small riverboat takes a group of travelers through a jungle filled with dangerous animals and reptiles but with a supernatural element.", R.drawable.jungle));
        datalist.add(new Movie("Cruella","On Cinema","Before she becomes Cruella de Vil, teenage Estella has a dream. She wishes to become a fashion designer, having been gifted with talent, innovation, and ambition all in equal measures. But life seems intent on making sure her dreams never come true.", R.drawable.cruel));
        datalist.add(new Movie("Dune","On Cinema","A mythic and emotionally charged hero's journey, Dune tells the story of Paul Atreides, a brilliant and gifted young man born into a great destiny beyond his understanding.", R.drawable.dune));
        datalist.add(new Movie("Black Widow","On Cinema","In Marvel Studios' action-packed spy thriller Black Widow, Natasha Romanoff aka Black Widow confronts the darker parts of her ledger when a dangerous conspiracy with ties to her past arises.", R.drawable.black));
        datalist.add(new Movie("Venom Let There Be Carnage","On Cinema","Eddie Brock struggles to adjust to his new life as the host of the alien symbiote Venom, which grants him super-human abilities in order to be a lethal vigilante.", R.drawable.venom));
        datalist.add(new Movie("Snake Eyes GI JOE","On Cinema","After saving the life of their heir apparent, tenacious loner Snake Eyes is welcomed into an ancient Japanese clan called the Arashikage where he is taught the ways of the ninja warrior.", R.drawable.snaker));
        datalist.add(new Movie("F9","On Cinema","Dom and the crew must take on an international terrorist who turns out to be Dom and Mia's estranged brother.", R.drawable.f9));
        datalist.add(new Movie("No Time To Die","On Cinema","Bond has left active service and is enjoying a tranquil life in Jamaica. His peace is short-lived when his old friend Felix Leiter from the CIA turns up asking for help.", R.drawable.no));
    }
}
