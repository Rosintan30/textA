package com.example.tiket_bioskop;

public class Movie {
    String nama;
    String movie;
    String des;
    int poto;

    public Movie(String nama, String movie, String des, int poto) {
        this.nama = nama;
        this.movie = movie;
        this.des = des;
        this.poto = poto;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getMovie() {
        return movie;
    }

    public void setMovie(String movie) {
        this.movie = movie;
    }

    public String getDes() {
        return des;
    }

    public void setDes(String des) {
        this.des = des;
    }

    public int getPoto() {
        return poto;
    }

    public void setPoto(int poto) {
        this.poto = poto;
    }
}
