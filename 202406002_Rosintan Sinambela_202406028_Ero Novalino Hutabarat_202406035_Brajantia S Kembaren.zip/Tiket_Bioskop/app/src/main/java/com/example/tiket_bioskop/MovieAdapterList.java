package com.example.tiket_bioskop;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class MovieAdapterList extends RecyclerView.Adapter<MovieAdapterList.MovieViewholder> {
    public MovieAdapterList(ArrayList<Movie> datalist) {
        this.datalist = datalist;
    }

    ArrayList<Movie> datalist;
    private OnItemClickCallback onItemClickCallback;

    @NonNull
    @Override
    public MovieViewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.movie_rvlayout, parent, false);
        return new MovieViewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final MovieViewholder holder, int position) {
        holder.tvnama.setText(datalist.get(position).getNama());
        //holder.civpoto.setImageResource(datalist.get(position).getPoto());
        Glide.with(holder.itemView.getContext()).load(datalist.get(position).getPoto()).into(holder.civpoto);

        holder.cvmov.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onItemClickCallback.onClicked(datalist.get(holder.getAdapterPosition()));
            }
        });
    }

    @Override
    public int getItemCount() {
        return datalist.size();
    }

    public class MovieViewholder extends RecyclerView.ViewHolder {
        CardView cvmov;
        ImageView civpoto;
        TextView tvnama;

        public MovieViewholder(@NonNull View itemView) {
            super(itemView);

            tvnama = (TextView) itemView.findViewById(R.id.tv_nama);
            civpoto = (ImageView) itemView.findViewById(R.id.civ_poto);
            cvmov = (CardView) itemView.findViewById(R.id.cv_mov);

        }
    }

    void setOnItemClickCallback(MovieAdapterList.OnItemClickCallback onItemClickCallback){
        this.onItemClickCallback = onItemClickCallback;
    }

    interface OnItemClickCallback{
        void onClicked(Movie data);
    }
}
