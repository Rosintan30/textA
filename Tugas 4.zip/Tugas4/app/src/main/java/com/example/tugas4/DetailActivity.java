package com.example.tugas4;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;


public class DetailActivity extends AppCompatActivity {
    ImageView civPhoto;
    TextView tvjudul, tvKeterangan, tvSinopsis;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        getSupportActionBar().setTitle("Detail Korean Drama");

        civPhoto = (ImageView) findViewById(R.id.detailciv_photo);
        tvjudul = (TextView) findViewById(R.id.detailtv_judul);
        tvKeterangan  = (TextView) findViewById(R.id.detailtv_keterangan);
        tvSinopsis = (TextView) findViewById(R.id.detailtv_sinopsis);

        String judul = getIntent().getStringExtra("EXTRA_JUDUL");
        String keterangan = getIntent().getStringExtra("EXTRA_KETERANGAN");
        String sinopsis = getIntent().getStringExtra("EXTRA_SINOPSIS");
        int photo = getIntent().getIntExtra("EXTRA_PHOTO", R.drawable.ic_launcher_background);

        tvjudul.setText(judul);
        tvKeterangan.setText(keterangan);
        tvSinopsis.setText(sinopsis);
        Glide.with(this).load(photo).into(civPhoto);
    }

}
