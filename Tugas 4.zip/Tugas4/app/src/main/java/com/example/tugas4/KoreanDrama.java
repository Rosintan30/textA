package com.example.tugas4;

public class KoreanDrama {

    String judul;
    String keterangan;
    String sinopsis;
    int photo;


    public KoreanDrama(String judul, String keterangan, String sinopsis, int photo) {
        this.judul = judul;
        this.keterangan = keterangan;
        this.sinopsis = sinopsis;
        this.photo = photo;
    }

    public String getJudul() {
        return judul;
    }

    public void setJudul(String judul) {
        this.judul = judul;
    }

    public String getKeterangan() {
        return keterangan;
    }

    public void setKeterangan(String keterangan) {
        this.keterangan = keterangan;
    }

    public String getSinopsis() {
        return sinopsis;
    }

    public void setSinopsis(String sinopsis) {
        this.sinopsis = sinopsis;
    }

    public int getPhoto() {
        return photo;
    }

    public void setPhoto(int photo) {
        this.photo = photo;
    }
}


