package com.example.tugas4;


import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class ListDramaKoreaAdapter extends RecyclerView.Adapter<ListDramaKoreaAdapter.MahasiswaViewHolder> {
        private ArrayList<KoreanDrama> dataList;
        private OnItemClickCallback onItemClickCallback;

        public ListDramaKoreaAdapter(ArrayList<KoreanDrama> dataList) {
            this.dataList = dataList;
        }

        @NonNull
        @Override
        public ListDramaKoreaAdapter.MahasiswaViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
            View view = layoutInflater.inflate(R.layout.koreandrama_rvlayout, parent, false);
            return new MahasiswaViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ListDramaKoreaAdapter.MahasiswaViewHolder holder, int position) {
            holder.tvJudul.setText(dataList.get(position).getJudul());
            holder.tvKeterangan.setText(dataList.get(position).getKeterangan());
            holder.tvSinopsis.setText(dataList.get(position).getSinopsis());
            //holder.civPhoto.setImageResource(dataList.get(position).getPhoto());
            Glide.with(holder.itemView.getContext()).load(dataList.get(position).getPhoto()).into(holder.civPhoto);

            holder.cvMahasiswa.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    onItemClickCallback.onClicked(dataList.get(holder.getAdapterPosition()));
                }
            });
        }

        @Override
        public int getItemCount() {
            return dataList.size();
        }

        public class MahasiswaViewHolder extends RecyclerView.ViewHolder {
            CardView cvMahasiswa;
            ImageView civPhoto;
            TextView tvJudul, tvKeterangan, tvSinopsis;
            public MahasiswaViewHolder(@NonNull View itemView) {
                super(itemView);

                tvJudul = (TextView) itemView.findViewById(R.id.tv_judul);
                tvKeterangan = (TextView) itemView.findViewById(R.id.tv_keterangan);
                tvSinopsis = (TextView) itemView.findViewById(R.id.tv_sinopsis);
                civPhoto = (ImageView) itemView.findViewById(R.id.civ_photo);
                cvMahasiswa = (CardView) itemView.findViewById(R.id.cv_koreandrama);
            }
        }

        void setOnItemClickCallback(ListDramaKoreaAdapter.OnItemClickCallback onItemClickCallback) {
            this.onItemClickCallback = onItemClickCallback;
        }

        interface OnItemClickCallback{
            void onClicked(KoreanDrama data);
        }
    }


