package com.example.tugas4;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    RecyclerView rvDramaKorea;
    ArrayList<KoreanDrama> dataList;
    private ArrayList<KoreanDrama> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().setTitle("Daftar Drama Korea");

        addData();
        rvDramaKorea = (RecyclerView) findViewById(R.id.rv_koreandrama);
        ListDramaKoreaAdapter listDramaKoreaAdapter = new ListDramaKoreaAdapter(dataList);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
        rvDramaKorea.setLayoutManager(layoutManager);
        rvDramaKorea.setAdapter(listDramaKoreaAdapter);


        listDramaKoreaAdapter.setOnItemClickCallback(new ListDramaKoreaAdapter.OnItemClickCallback(){
            @Override
            public void onClicked(KoreanDrama data) {
                Intent intent = new Intent(MainActivity.this, DetailActivity.class);
                intent.putExtra("EXTRA_JUDUL", data.getJudul());
                intent.putExtra("EXTRA_KETERANGAN", data.getKeterangan());
                intent.putExtra("EXTRA_SINOPSIS", data.getSinopsis());
                intent.putExtra("EXTRA_PHOTO", data.getPhoto());
                startActivity(intent);
            }
        });
    }


    void addData(){
        dataList = new ArrayList<KoreanDrama>();
        dataList.add(new KoreanDrama("Crash Landing On You", "2019. Roman. 1 Season", "Se-Ri menimbulkan kekacauan bagi Jung-Hyeok, yang membawakan produk kecantikan. Mereka saling mempelajari dunia baru.", R.drawable.crashlanding));
        dataList.add(new KoreanDrama("Doctors", "2016. Drama. 1 Season","Dua mantan sahabat pena bersatu lagi dan berjuang di dunia teknologi untuk membangun impian, aplikasi, dan cinta.", R.drawable.doctors));
        dataList.add(new KoreanDrama("Start Up", "2020. Drama. 1 Season","Siswi bandel. Guru dan masa lalu kelam. Akankah pertemuan keduanya mengubah hidup mereka?", R.drawable.startup));
        dataList.add(new KoreanDrama("The King", "2020. Roman. 1 Season","Merasa sedih atas kesialan yang menimpanya, seorang wanita pindah ke pulau Jeju yang indah. Disana ia bertemu seorang koki yang riang dan tak terlalu berambisi.", R.drawable.theking));
        dataList.add(new KoreanDrama("Warm and Cozy", "2015. Roman. 1 Season","Seorang kaisar korea zaman modern melewati portal misterius hingga masuk ke dunia pararel. Disana, ia berjumpai seorang detektif polisi pemberani.", R.drawable.warmandcozy));
        dataList.add(new KoreanDrama("Home Town Cha-cha-cha", "2021, Komedi roman, 1 Season","Hometown Cha-Cha-Cha mengisahkan tentang seorang dokter gigi yang perfeksionis dan seorang pria yang pengangguran. Dokter gigi tersebut bernama Yoon Hye Jin(Shin Min Ah)", R.drawable.hometownchachacha));
        dataList.add(new KoreanDrama("Descendant", "2015. Musikal/Fantasi. 1j 52m","Pangeran baik hati, putra raja Adam dan Ratu Belle mengundang anak anak para penjahat untuk sekolah di kerajaannya. Ia menawarkan mereka kesempatan untuk menebus kesalahan dan mengabdi pada kerajaan.", R.drawable.descendant));
        dataList.add(new KoreanDrama("The legend of Blue Sea", "2016. Roman. 1 Season","Serial The Legend of Blue Sea ini diadaptasi dari cerita Korea, dimana mengisahkan tentang seorang putri duyung bernama She-hwa yang menyelamatkan seorang pria bernama Dam ryeong ", R.drawable.legendbluesea));
        dataList.add(new KoreanDrama("What Happend with My Family", "2014. Drama","Serial What happens to My Family mengisahkan tentang keluarga yang tak bahagia dan kacau Moon Tae-Joon diperankan oleh Kim Sang-Kyung merupakan sseorang pegawai terbaik di perusahaan Daeoh", R.drawable.whathappenstomyfamily));
        dataList.add(new KoreanDrama("The Tale of Nine Tale", "2020. Drama. 1 Season","KDrama yang mengangkat genre Romance dan Fantasy ini menggantikan seri drakor 'Flower of Evil'.", R.drawable.tailofninetail));


    }
}